
from flask import Flask, request, jsonify, render_template
import paramiko, json

app = Flask(__name__)

def load_json(p):
    with open(p) as f: return json.load(f)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/settings")
def settings():
    return render_template("settings.html")

@app.route("/api/bngs")
def bngs():
    return jsonify(load_json("data/bngs.json"))

@app.route("/api/settings", methods=["GET","POST"])
def settings_api():
    if request.method == "GET":
        return jsonify({
            "bngs": load_json("data/bngs.json"),
            "credentials": load_json("data/credentials.json"),
            "commands": load_json("data/commands.json")
        })
    data = request.json
    json.dump(data["bngs"], open("data/bngs.json","w"), indent=2)
    json.dump(data["credentials"], open("data/credentials.json","w"), indent=2)
    json.dump(data["commands"], open("data/commands.json","w"), indent=2)
    return {"status":"saved"}

@app.route("/api/validate", methods=["POST"])
def validate():
    d = request.json
    bng = next(b for b in load_json("data/bngs.json") if b["name"]==d["bng"])
    creds = load_json("data/credentials.json")
    cmds = load_json("data/commands.json")

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(bng["ip"], username=creds["username"], password=creds["password"], timeout=10)

    res=[]
    for c in cmds:
        _,out,err = ssh.exec_command(c)
        o = out.read().decode()+err.read().decode()
        res.append({"command":c,"output":o,"status":"PASS" if o.strip() else "FAIL"})
    ssh.close()
    return jsonify(res)

app.run(debug=True)
